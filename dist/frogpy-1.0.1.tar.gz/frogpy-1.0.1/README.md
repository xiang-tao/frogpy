# frogpy
Shared Python files to achieve some mathematical algorithms and equation solving
